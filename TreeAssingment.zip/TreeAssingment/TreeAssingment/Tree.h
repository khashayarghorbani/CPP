//
//  Tree.h
//  TreeAssingment
//
//  Created by Khashayar Ghorbani on 2020-06-20.
//  Copyright © 2020 Khashayar Ghorbani. All rights reserved.
//

#ifndef Tree_h
#define Tree_h
#include <iostream>

using std::endl;

#include <new>
#include "lotNumber.h"

template< class NODETYPE >
class Tree {

public:
   Tree();
   void insertNode( const NODETYPE & );
   void preOrderTraversal() const;
   void inOrderTraversal() const;
   void postOrderTraversal() const;
    void deleteTraversal();
    void deleteNodeTrsversal();
   

private:
   lotNumber< NODETYPE > *rootPtr;

    void deleteTree(lotNumber<NODETYPE>*);
    void deleteNode(lotNumber<NODETYPE>*,lotNumber< NODETYPE >*n);
   void insertNodeHelper(lotNumber< NODETYPE > **, const NODETYPE & );
   void preOrderHelper( lotNumber< NODETYPE > * ) const;
   void inOrderHelper( lotNumber< NODETYPE > * ) const;
   void postOrderHelper( lotNumber< NODETYPE > * ) const;

};
template< class NODETYPE >
Tree< NODETYPE >::Tree()
{
   rootPtr = 0;

}
template< class NODETYPE >
void Tree< NODETYPE >::insertNode( const NODETYPE &value )
{
   insertNodeHelper( &rootPtr, value );

}
template< class NODETYPE >
void Tree< NODETYPE >::insertNodeHelper(
   lotNumber< NODETYPE > **ptr, const NODETYPE &value )
{
   if ( *ptr == 0 )
      *ptr = new lotNumber< NODETYPE >( value );

   else
      if ( value < ( *ptr )->data )
         insertNodeHelper( &( ( *ptr )->leftPtr ), value );

      else
         if ( value > ( *ptr )->data )
            insertNodeHelper( &( ( *ptr )->rightPtr ), value );

         else
            cout << value << " dup" << endl;

}
template< class NODETYPE >
void Tree< NODETYPE >::preOrderTraversal() const
{
   preOrderHelper( rootPtr );

}
template< class NODETYPE >
void Tree< NODETYPE >::deleteTree(lotNumber<NODETYPE>*node)
{
    
    if (node == NULL) return;
  
    deleteTree(node->leftPtr);
    deleteTree(node->rightPtr);
      
    cout << "\n Deleting node: " << node->data;
    delete node;
}
template< class NODETYPE >
void Tree< NODETYPE >::preOrderHelper(
   lotNumber< NODETYPE > *ptr ) const
{
   if ( ptr != 0 ) {
      cout << ptr->data << ' ';
      preOrderHelper( ptr->leftPtr );
      preOrderHelper( ptr->rightPtr );

   }

}
template< class NODETYPE >
void Tree<NODETYPE>::deleteNode(lotNumber< NODETYPE >*head, lotNumber< NODETYPE >*n)
{
    if(head == n)
    {
        if(head->rightPtr == NULL)
        {
            cout << "There is only one node." <<
                    " The list can't be made empty ";
            return;
        }
  
        head->data = head->rightPtr->data;
  
        n = head->rightPtr;

        head->rightPtr = head->rightPtr->rightPtr;

        free(n);
  
        return;
    }
}
template< class NODETYPE >
void Tree< NODETYPE >::inOrderTraversal() const
{
   inOrderHelper( rootPtr );

}
template< class NODETYPE >
void Tree< NODETYPE >::inOrderHelper(
   lotNumber< NODETYPE > *ptr ) const
{
   if ( ptr != 0 ) {
      inOrderHelper( ptr->leftPtr );
      cout << ptr->data << ' ';
      inOrderHelper( ptr->rightPtr );

   }

}
template< class NODETYPE >
void Tree< NODETYPE >::postOrderTraversal() const
{
   postOrderHelper( rootPtr );

}
template< class NODETYPE >
void Tree< NODETYPE >::deleteTraversal(){
    deleteTree(rootPtr);
}
template< class NODETYPE >
void Tree<NODETYPE>::deleteNodeTrsversal(){
    deleteNode(rootPtr,rootPtr);
}

template< class NODETYPE >
void Tree< NODETYPE >::postOrderHelper(
   lotNumber< NODETYPE > *ptr ) const
{
   if ( ptr != 0 ) {
      postOrderHelper( ptr->leftPtr );
      postOrderHelper( ptr->rightPtr );
      cout << ptr->data << ' ';

   }

} 


#endif /* Tree_h */
