//
//  lotNumber.h
//  TreeAssingment
//
//  Created by Khashayar Ghorbani on 2020-06-20.
//  Copyright © 2020 Khashayar Ghorbani. All rights reserved.
//

#ifndef lotNumber_h
#define lotNumber_h

template< class NODETYPE > class Tree;

template< class NODETYPE >

class lotNumber {
   friend class Tree< NODETYPE >;

public:


   lotNumber( const NODETYPE &d )
      : leftPtr( 0 ),
        data( d ),
        rightPtr( 0 )
   {
     
   
   } 
   NODETYPE getData() const
   {
      return data;

   }
   

private:
   lotNumber< NODETYPE > *leftPtr;
   NODETYPE data;
   lotNumber< NODETYPE > *rightPtr;

};



#endif /* lotNumber_h */
