#include <iostream>

using std::cout;
using std::cin;
using std::fixed;

#include <iomanip>
using std::setprecision;
#include "lotNumber.h"
#include "Tree.h"



int main()
{
    Tree<int>intTree;
   int intValue,amount;
   cout << "how many parking lot do we have?\n";
    cin>>amount;

   for( int i = 0; i < amount; i++ ) {
       cout<<"how many space does parking lot "<<i+1<<" has?"<<endl;
      cin >> intValue;
       intTree.insertNode( intValue );

   }

   cout << "\nPreorder traversal\n";
    intTree.preOrderTraversal();

   cout << "\nInorder traversal\n";
    intTree.inOrderTraversal();

   cout << "\nPostorder traversal\n";
    intTree.postOrderTraversal();
    cout<<"\nDeleting first nodes"<<endl;
    intTree.deleteNodeTrsversal();
    intTree.inOrderTraversal();
    cout<<"\nDelete everything"<<endl;
    intTree.deleteTraversal();
    
    cout<<endl;
  
   
   return 0;

} 
