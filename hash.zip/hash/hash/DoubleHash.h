//
//  DoubleHash.h
//  hash
//
//  Created by Khashayar Ghorbani on 2020-06-25.
//  Copyright © 2020 Khashayar Ghorbani. All rights reserved.
//

#ifndef DoubleHash_h
#define DoubleHash_h
#include<iostream>
#include<vector>
using namespace std;
class DoubleHash {
    double* hashTable;
    int curr_size;
  
public:
    bool isFull()
    {
  
        return (curr_size == 200);
    }
  
    double hash1(double key)
    {
        return int((key*199)) % 199;
    }

    double hash2(double key)
    {
        return 199 - int(key) % 199;
    }
  
    DoubleHash()
    {
        hashTable = new double[200];
        curr_size = 0;
        for (int i = 0; i < 200; i++)
            hashTable[i] = -1;
    }
  
    void insertHash(double key)
    {
        
        if (isFull())
            return;
  
        int index = hash1(key);
        if (hashTable[index] != -1) {
            double index2 = hash2(key);
            int i = 1;
            while (1) {
                double newIndex = int(index + i * index2) % 200;
                if (hashTable[int(newIndex)] == -1) {
                    hashTable[int(newIndex)] = key;
                    break;
                }
                i++;
            }
        }

        else
            hashTable[index] = key;
        curr_size++;
    }
   
    void search(double key)
    {
        double index1 = hash1(key);
        double index2 = hash2(key);
        int i = 0;
        while (hashTable[int(index1 + i * index2) % 200] != key) {
            if (hashTable[int(index1 + i * index2) % 200] == -1) {
                cout << key << " does not exist" << endl;
                return;
            }
            i++;
        }
        cout << key << " found" << endl;
    }
  
    void displayHash()
    {
        for (int i = 0; i < 200; i++) {
            if (hashTable[i] != -1)
                cout << i << " --> "
                     << hashTable[i] << endl;
            else
                cout << i << endl;
        }
    }
};
  


#endif /* DoubleHash_h */
