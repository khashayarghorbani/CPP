//
//  Menu.h
//  hash
//
//  Created by Khashayar Ghorbani on 2020-06-25.
//  Copyright © 2020 Khashayar Ghorbani. All rights reserved.
//

#ifndef Menu_h
#define Menu_h
#include<iostream>
#include<vector>
#include "SeperateHash.h"
#include "LinearProbing.h"
#include "DoubleHash.h"
using namespace std;
void menu(){
    int choice,choiceDisplay;
        double deleting;
       DoubleHash doubleHash;
       HashMap<int, double> *h = new HashMap<int,double>;
       SeperateHash obj(200);
       double arr[202];
       for (int i=0; i<200; i++) {
        double iRandom = 0 + (double)rand() / RAND_MAX * (1-0);
        arr[i]=iRandom;
        h->insertNode(i, iRandom);
        doubleHash.insertHash(iRandom);
       }
        for (int i = 0; i < 200; i++){
        obj.add(arr[i]);
        }
       cout<<"please choose one"<<endl;
       cout<<"1- SeperateHash"<<endl;
       cout<<"2-Linear Probing"<<endl;
       cout<<"3-Double hash"<<endl;
       cout<<"4-Exit\n";
       cin>>choice;
    while(choice !=0){
       switch (choice) {
           case 1:
               cout<<"Please select one"<<endl;
               cout<<"1-display"<<endl;
               cout<<"2-delete"<<endl;
               cout<<"3-go back"<<endl;
               cin>>choiceDisplay;
               switch (choiceDisplay) {
                   case 1:
                      
                       cout << "Initial Hash:\n";
                       obj.displayHash();

                       break;
                  case 2:
                      cout<<"Insert the index you want to delete/n";
                      obj.displayHash();
                      cin>>deleting;
                       obj.del(deleting);
                      break;
                   case 3:
                       menu();
                  default:
                      break;
               }
               break;
           case 2:
               cout<<"Please select one"<<endl;
               cout<<"1-display"<<endl;
               cout<<"2-delete"<<endl;
               cout<<"3-search for number"<<endl;
               cout<<"4-go back"<<endl;
               
               cin>>choiceDisplay;
               switch (choiceDisplay) {
                   case 1:
                       cout << "Initial Hash:\n";
                       h->display();
                       break;
                   case 2:
                       cout<<"Insert the index you want to delete\n";
                       h->display();
                       cin>>deleting;
                       h->deleteNode(deleting);
                       break;
                   case 3:
                       cout<<"Insert the index you want to get\n";
                       cin>>deleting;
                       h->get(deleting);
                       break;
                   case 4:
                       menu();
                       break;
                   default:
                       break;
               }
               break;
           case 3:
               cout<<"Please select one"<<endl;
               cout<<"1-display"<<endl;
               cout<<"2-delete"<<endl;
               cout<<"3-search for number"<<endl;
               cout<<"4-go back"<<endl;
               cin>>choiceDisplay;
               switch (choiceDisplay) {
                   case 1:
                       cout << "Initial Hash:\n";
                       doubleHash.displayHash();
                       break;
                   case 2:
                       cout<<"Insert the index you want to delete\n";
                       doubleHash.displayHash();
                       cin>>deleting;
                       h->deleteNode(deleting);
                                   
                       break;
                   case 3:
                       cout<<"Insert the index you want to get\n";
                       cin>>deleting;
                       doubleHash.search(deleting);
                       break;
                   case 4:
                       menu();
                       break;
                   default:
                       break;
                          }
               break;
           case 4:
               exit(0);
           default:
               break;
       }
       
       }
}


#endif /* Menu_h */
