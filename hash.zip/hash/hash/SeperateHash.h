//
//  SeperateHash.h
//  hash
//
//  Created by Khashayar Ghorbani on 2020-06-25.
//  Copyright © 2020 Khashayar Ghorbani. All rights reserved.
//

#ifndef SeperateHash_h
#define SeperateHash_h
#include<iostream>
#include<vector>
using namespace std;
class SeperateHash {
  
private:
    double n;
    vector<vector<double> > v;
public:
    SeperateHash(double n)
    {
        
        v = vector<vector<double> >(n);
  
        this->n = n;
    }
  
    int getHashIndex(double x)
    {
        return int((x*199)) % 199;
    }
  
    void add(double x)
    {
        v[getHashIndex(x)].push_back(x);
    }
  
    void del(double x)
    {
        double i = getHashIndex(x);
        for (int j = 0; j < v[i].size(); j++) {
            if (v[i][j] == x) {
                v[i].erase(v[i].begin() + j);
                cout << x << " deleted!" << endl;
                return;
            }
        }
  
        cout << "No Element Found!" << endl;
    }
    void displayHash()
    {
        for (int i = 0; i < v.size(); i++) {
            cout << i;
            for (int j = 0; j < v[i].size(); j++)
                cout << " -> " << v[i][j];
            cout << endl;
        }
    }
};

#endif /* SeperateHash_h */
