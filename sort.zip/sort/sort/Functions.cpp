//
//  Functions.cpp
//  sort
//
//  Created by Khashayar Ghorbani on 2020-06-17.
//  Copyright © 2020 Khashayar Ghorbani. All rights reserved.
//
#include <iostream>
#include <stdio.h>
#include "prototypes.h"
#include <vector>
using std::cout;
using std::cin;
using std::endl;
int size;
void indexSort(std::vector<int>&numberVector){
    std::vector<int> fValue2( numberVector );
    std::sort( fValue2.begin(), fValue2.end() );
    printV(&fValue2);
}
void TagSort(std::vector<int>&tagVector,std::vector<int>&numberVector)
{
     int k, indexOfMin, pass;
     for (k = 0; k < size; k++)
           tagVector[k] = k;

     for (pass = 0; pass < size - 1; pass++)
     {
           indexOfMin = pass;

           for (k = pass + 1; k < size; k++)
                 if (numberVector[tagVector[k]] < numberVector[tagVector[indexOfMin]])
                       indexOfMin = k;

           if (indexOfMin != pass)
                 swap(&tagVector[pass], &tagVector[indexOfMin]);
     }
}

int partition (std::vector<int>&numberVector, int low, int high)
{
    int pivot = numberVector[high];
    int i = (low - 1);
  
    for (int j = low; j <= high - 1; j++)
    {
        if (numberVector[j] < pivot)
        {
            i++;
            swap(&numberVector[i], &numberVector[j]);
        }
    }
    swap(&numberVector[i + 1], &numberVector[high]);
    return (i + 1);
}
  

void quickSort(std::vector<int>&numberVector, int low, int high)
{
    if (low < high)
    {

        int pi = partition(numberVector, low, high);
        quickSort(numberVector, low, pi - 1);
        quickSort(numberVector, pi + 1, high);
    }
}
void heapify(std::vector<int>&numberVector, int n, int i)
{
    int largest = i;
    int l = 2*i + 1;
    int r = 2*i + 2;
    if (l < n && numberVector[l] > numberVector[largest])
        largest = l;
    if (r < n && numberVector[r] > numberVector[largest])
        largest = r;
    if (largest != i)
    {
        swap(&numberVector[i], &numberVector[largest]);
        heapify(numberVector, n, largest);
    }
}
void heapSort(std::vector<int>&numberVector)
{
    
    for (int i = size / 2 - 1; i >= 0; i--)
        heapify(numberVector, size, i);
  
   
    for (int i=size-1; i>0; i--)
    {
        swap(&numberVector[0], &numberVector[i]);
        heapify(numberVector, i, 0);
    }
    printV(&numberVector);
}
void merge(std::vector<int>& numberVector, int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;
  
    int L[n1], R[n2];
  
    for (i = 0; i < n1; i++)
        L[i] = numberVector[l + i];
    for (j = 0; j < n2; j++)
        R[j] = numberVector[m + 1 + j];
  
    i = 0;
    j = 0;
    k = l;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            numberVector[k] = L[i];
            i++;
        }
        else {
            numberVector[k] = R[j];
            j++;
        }
        k++;
    }
  
    while (i < n1) {
        numberVector[k] = L[i];
        i++;
        k++;
    }
  
  
    while (j < n2) {
        numberVector[k] = R[j];
        j++;
        k++;
    }
}
  

void mergeSort(std::vector<int>& numberVector, int l, int r)
{
    if (l < r) {
       
        int m = l + (r - l) / 2;
  
        mergeSort(numberVector, l, m);
        mergeSort(numberVector, m + 1, r);
  
        merge(numberVector, l, m, r);
    }
    
}

void printV(std::vector<int>* vec){
    std::ostream_iterator< int > output( cout, " " );
    std::copy(vec->begin(),vec->end(),output);
    cout<<endl;
}
void swap(int *number1, int *number2)
{
    int temp = *number1;
    *number1 = *number2;
    *number2 = temp;
}

  


void bucketSort(std::vector<int>*numberVector) {
   std::vector<int> bucket;
    for(int i = 0; i<size; i++)  {
       bucket.push_back(numberVector->at(i));
   }

   sort(bucket.begin(), bucket.end());
    printV(&bucket);

}
void shellSort(std::vector<int>numberVector)
{
    for (int gap = size/3; gap > 0; gap /= 3)
    {
        for (int i = gap; i < size; i += 1)
        {
            int temp = numberVector[i];
            int j;
            for (j = i; j >= gap && numberVector[j - gap] > temp; j -= gap)
                numberVector[j] = numberVector[j - gap];
            numberVector[j] = temp;
        }
    }
printV(&numberVector);
}
void insertionSort(std::vector<int>numberVector){
int i, key, j;

  for (i = 1; i < size; i++)
  {
      key = numberVector[i];
      j = i - 1;

      while (j >= 0 && numberVector[j] > key)
      {
          numberVector[j + 1] = numberVector[j];
          j = j - 1;
      }
      numberVector[j + 1] = key;
  }
    printV(&numberVector);
}
void bubbleSort(std::vector<int>&numberVector){
int i, j;
for (i = 0; i < size-1; i++){
    for (j = 0; j < size-i-1; j++){
        if (numberVector[j] > numberVector[j+1])
            swap(&numberVector[j], &numberVector[j+1]);
        }
    }
}


void menu(){
    
    std::vector<int> numberVector;
    std::vector<int>tag;
    int amount,index,sortChoice;
    cout<<"Please choose your sort"<<endl;
    cout<<"1-Insertion Sort\n2-Bubble Sort\n3-Tag Sort\n4-Shell Sort\n5-Bucket sort\n6-Quick sort\n7-Merge Sort\n8-Heap Sort\n9-Index Sort\n0-Exit"<<endl;
    cin>>sortChoice;
    
    switch (sortChoice) {
        case 1:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }

            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
               numberVector.push_back(index);
                
            }
            
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
            size = numberVector.size();
            cout<<"This is Insertion sort"<<endl;
            insertionSort(numberVector);
            menu();
            break;
        case 2:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }

            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
               numberVector.push_back(index);
                
            }
            
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
            size = numberVector.size();
            cout<<"This is Bubble sort"<<endl;
            bubbleSort(numberVector);
            printV(&numberVector);
            menu();
            break;
        //put Tag sort Here please*****************************************************************
        case 3:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }

            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
                tag.push_back(i);
               numberVector.push_back(index);
                
            }
            
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
            size = numberVector.size();
            cout<<"This is Tag sort"<<endl;
            TagSort(tag,numberVector);
            cout<<"This is Tag Vector"<<endl;
            printV(&tag);
            cout<<"This is sorted"<<endl;
            for (int i=0;i<size ; i++) {
                cout<<numberVector[tag[i]]<< " ";
            }
            cout<<endl;
            
            menu();
            break;
            
            case 4:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }
            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
               numberVector.push_back(index);
                
            }
            
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
            size  = numberVector.size();
            cout<<"This is Shell sort"<<endl;
            shellSort(numberVector);
            menu();
            break;
            
        case 5:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }

            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
               numberVector.push_back(index);
                
            }
            
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
            size = numberVector.size();
            cout<<"This is Bucket sort"<<endl;
            bucketSort(&numberVector);
            menu();
            break;
            
            case 6:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }

            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
               numberVector.push_back(index);
                
            }
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
             size = numberVector.size();
            cout<<"This is Quick sort"<<endl;
            quickSort(numberVector,0,size-1);
            printV(&numberVector);
            menu();
            break;
            
        case 7:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }

            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
               numberVector.push_back(index);
                
            }
            
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
             size = numberVector.size();
            cout<<"This is Merg sort"<<endl;
            mergeSort(numberVector,0,size-1);
            printV(&numberVector);
            menu();
            break;
            
        case 8:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }

            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
               numberVector.push_back(index);
                
            }
            
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
             size = numberVector.size();
            cout<<"This is Heap sort"<<endl;
            heapSort(numberVector);
            menu();
            break;
        case 9:
            cout<<"How many numbers more than 4 do you want to insert?"<<endl;
            cin>>amount;
            if (amount < 4) {
                cout<<"Sorry please put more than 4 number"<<endl;
                menu();
            }

            for (int i = 0; i <amount; i++) {
                cout<<"Please insert number "<<i+1<<" :"<<endl;
                cin>>index;
               numberVector.push_back(index);
                
            }
            cout<<"This is your numbers: "<<endl;
            printV(&numberVector);
             size = numberVector.size();
            cout<<"This is Index sort"<<endl;
            indexSort(numberVector);
            menu();
            break;
        case 0:
            exit(0);
        default:
            cout << "Please insert a Valid number !";
            break;
    }
}
    
   
