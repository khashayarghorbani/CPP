//
//  main.cpp
//  sort
//
//  Created by Khashayar Ghorbani on 2020-06-11.
//  Copyright © 2020 Khashayar Ghorbani. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>

using std::cout;
using std::cin;
using std::endl;
void menu();


int main(int argc, const char * argv[]) {
    // insert code here...
    menu();
    return 0;
}
  



