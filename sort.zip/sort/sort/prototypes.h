//
//  prototypes.h
//  sort
//
//  Created by Khashayar Ghorbani on 2020-06-17.
//  Copyright © 2020 Khashayar Ghorbani. All rights reserved.
//

#ifndef prototypes_h
#define prototypes_h
void swap(int *number1, int *number2);
void bubbleSort(std::vector<int>*numberVector);
void insertionSort(std::vector<int>numberVector);
void shellSort(std::vector<int>numberVector);
void bucketSort(std::vector<int>*numberVector);
void menu();
void printV(std::vector<int>* vec);
void mergeSort(std::vector<int>& numberVector, int l, int r);
void merge(std::vector<int>& numberVector, int l, int m, int r);
void heapSort(std::vector<int>&numberVector);
void heapify(std::vector<int>&numberVector, int n, int i);
void quickSort(std::vector<int>&numberVector, int low, int high);
int partition (std::vector<int>&numberVector, int low, int high);

#endif /* prototypes_h */
